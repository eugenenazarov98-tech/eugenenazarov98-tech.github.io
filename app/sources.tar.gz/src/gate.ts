/**
 * Простая парольная защита сайта (client-side gate).
 * Выполняется синхронно при импорте — до рендера React,
 * поэтому контент не успевает отобразиться без пароля.
 * Разблокировка запоминается в localStorage; смена пароля
 * (хэша ниже) автоматически сбрасывает все прошлые входы.
 */

const PASSWORD_SHA256 =
  "ac9432851d79e26c654f0c047fea4bb3d323b4da52b96e6a3451724c05da438c"; // sk_XEternal_tk
const STORAGE_KEY = "mge_gate_ok_v1";

function isUnlocked(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) === PASSWORD_SHA256;
  } catch {
    return false;
  }
}

async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(text)
  );
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function showGate() {
  const style = document.createElement("style");
  style.textContent = `
    #mge-gate {
      position: fixed; inset: 0; z-index: 2147483647;
      display: flex; align-items: center; justify-content: center;
      background: radial-gradient(1200px 800px at 50% 20%, #1e293b 0%, #0f172a 60%, #020617 100%);
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
      padding: 24px;
    }
    #mge-gate .card {
      width: 100%; max-width: 380px;
      background: rgba(255, 255, 255, 0.06);
      border: 1px solid rgba(255, 255, 255, 0.12);
      border-radius: 20px;
      padding: 36px 32px 32px;
      backdrop-filter: blur(12px);
      box-shadow: 0 24px 64px rgba(0, 0, 0, 0.45);
      text-align: center;
    }
    #mge-gate .lock {
      width: 56px; height: 56px; margin: 0 auto 18px;
      border-radius: 16px;
      background: linear-gradient(135deg, #3b82f6, #6366f1);
      display: flex; align-items: center; justify-content: center;
      box-shadow: 0 8px 24px rgba(99, 102, 241, 0.4);
    }
    #mge-gate h1 {
      color: #f1f5f9; font-size: 20px; font-weight: 600;
      margin: 0 0 6px;
    }
    #mge-gate p {
      color: #94a3b8; font-size: 13.5px; line-height: 1.5;
      margin: 0 0 22px;
    }
    #mge-gate input {
      width: 100%; box-sizing: border-box;
      padding: 12px 14px; font-size: 15px;
      color: #f1f5f9; background: rgba(15, 23, 42, 0.7);
      border: 1px solid rgba(148, 163, 184, 0.35);
      border-radius: 12px; outline: none;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    #mge-gate input:focus {
      border-color: #818cf8;
      box-shadow: 0 0 0 3px rgba(129, 140, 248, 0.25);
    }
    #mge-gate button {
      width: 100%; margin-top: 12px;
      padding: 12px 14px; font-size: 15px; font-weight: 600;
      color: #fff; border: none; border-radius: 12px; cursor: pointer;
      background: linear-gradient(135deg, #3b82f6, #6366f1);
      transition: transform 0.1s, filter 0.15s;
    }
    #mge-gate button:hover { filter: brightness(1.08); }
    #mge-gate button:active { transform: scale(0.98); }
    #mge-gate .err {
      display: none; margin-top: 12px;
      color: #fca5a5; font-size: 13px;
    }
    #mge-gate.shake .card { animation: mge-shake 0.4s; }
    @keyframes mge-shake {
      0%, 100% { transform: translateX(0); }
      20% { transform: translateX(-9px); }
      40% { transform: translateX(8px); }
      60% { transform: translateX(-6px); }
      80% { transform: translateX(4px); }
    }
  `;

  const overlay = document.createElement("div");
  overlay.id = "mge-gate";
  overlay.innerHTML = `
    <div class="card">
      <div class="lock">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none"
             stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="3" y="11" width="18" height="11" rx="2"/>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        </svg>
      </div>
      <h1>Доступ ограничен</h1>
      <p>Сайт находится в закрытом доступе.<br/>Введите пароль, чтобы продолжить.</p>
      <form id="mge-gate-form">
        <input id="mge-gate-input" type="password" autocomplete="current-password"
               placeholder="Пароль" aria-label="Пароль" />
        <button type="submit">Войти</button>
      </form>
      <div class="err" id="mge-gate-err">Неверный пароль. Попробуйте ещё раз.</div>
    </div>
  `;

  const mount = () => {
    document.documentElement.appendChild(style);
    document.body.appendChild(overlay);
    const input = overlay.querySelector<HTMLInputElement>("#mge-gate-input")!;
    const form = overlay.querySelector<HTMLFormElement>("#mge-gate-form")!;
    const err = overlay.querySelector<HTMLElement>("#mge-gate-err")!;
    input.focus();

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const digest = await sha256(input.value);
      if (digest === PASSWORD_SHA256) {
        try {
          localStorage.setItem(STORAGE_KEY, digest);
        } catch {
          /* приватный режим — просто не запоминаем */
        }
        overlay.remove();
        style.remove();
      } else {
        err.style.display = "block";
        input.select();
        overlay.classList.remove("shake");
        void overlay.offsetWidth; // перезапуск анимации
        overlay.classList.add("shake");
      }
    });
  };

  if (document.body) {
    mount();
  } else {
    document.addEventListener("DOMContentLoaded", mount, { once: true });
  }
}

if (!isUnlocked()) {
  showGate();
}

export {};
